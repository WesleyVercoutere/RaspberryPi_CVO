package de.UllisRoboterSeite.UrsAI2MQTT;;

/**
 * \brief Schnittstelle zu einem MQTT-Übertragungskanal.
 */
public interface IMqttChannel {
    /**
     * \brief Stellt eine (Netzwerk-) Verbindung zum Broker her.
     *
     * @throws MqttException Die Verbindung besteht nicht mehr.
     */
    public void connect() throws MqttException;

    /**
     * \brief Unterbricht die Verbindung.
     */
    public void disconnect();

    /**
     * \brief Gibt an, ob Daten zum Einlesen zur Verfügung stehen.
     *
     * @return true, wenn Daten eingelesen werden können.
     * @throws MqttException Die Verbindung besteht nicht mehr.
     */
    public boolean available() throws MqttException;

    /**
     * \brief Liefert ein einzelnes Byte.
     *
     * @return Das eingelesene Byte.
     * @throws MqttException IO-Fehler oder Timeout. Beides bedeutet
     *                       Verbindungsabbruch.
     */
    public byte readByteTimeout() throws MqttException;

    /**
     * @brief Versendet ein Datenpaket (Byte-Array).
     * @param data Das zu versendende Byte-Array.
     * @throws MqttException Die Verbindung besteht nicht mehr.
     */
    public void xmit(byte[] data) throws MqttException;
}