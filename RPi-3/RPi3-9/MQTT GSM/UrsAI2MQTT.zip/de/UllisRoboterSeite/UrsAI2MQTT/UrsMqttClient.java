package de.UllisRoboterSeite.UrsAI2MQTT;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * \brief MQTT-Client
 */
public class UrsMqttClient implements IMqttListener {
    private static class Runner {
        static void start(Runnable r) {
            Thread t1 = new Thread(r);
            t1.start();
        }
    }

    public static final Charset Charset = StandardCharsets.UTF_8;
    IMqttChannel mqttChannel = null; // ist null, wenn nicht verbunden
    volatile MqttConnectionState connectionState = MqttConnectionState.Disconnected;
    IExtensionListener _appListener = null;

    MqttMessageHandler mrt = null;

    // #region Constructors
    /**
     * Initialisiert eine neue Instanz der Klasse UrsMqttClient.
     *
     * @param listener Listener für MQTT-Nachrichten.
     */
    public UrsMqttClient(IExtensionListener listener) {
        _appListener = listener;
    }
    // #endregion

    // #region Events
    /**
     * \brief Event wird ausgelöst, wenn sich der Verbindungszustand geändert hat.
     *
     * @param newState  Der neue Verbindungszustand
     * @param errorCode
     */
    public void ConnectionStateChangedEvent(MqttConnectionState newState, int errorCode, String errorText) {
        connectionState = newState;
        System.out.println("Verbindungsstatus ist: " + newState.toString());
        _appListener.ConnectionStateChangeCallback(newState, errorCode, errorText);
    }

    // #endregion

    // #region IMqttListener
    /**
     * \brief Methode wird beim Empfang von einer CONNACK-Nachricht aufgerufen.
     */
    @Override
    public void ConnectedAckCallback(MsgConnAck msg) {
        if (msg.connectReturnCode == 0) {
            ConnectionStateChangedEvent(MqttConnectionState.Connected, 0, "");
        } else {
            String text = "";
            switch (msg.connectReturnCode) {
                case 1:
                    text = "Unacceptable protocol version";
                    break;
                case 2:
                    text = "Identifier rejected";
                    break;
                case 3:
                    text = "Server unavailable";
                    break;
                case 4:
                    text = "Bad user name or password";
                    break;
                case 5:
                    text = "Not authorized";
                    break;
                default:
                    break;
            }
            stopReceiver();
            mqttChannel.disconnect();
            ConnectionStateChangedEvent(MqttConnectionState.ConnectionAbortet, msg.connectReturnCode, text);
        }
    }

    /**
     * \brief Methode wird beim Empfang von einer PUBLISH-Nachricht aufgerufen.
     */
    @Override
    public void PublishedReceivedCallback(MsgPublish mp) {
        _appListener.PublishedReceivedCallback(mp);
    }

    /**
     * \brief Methode wird beim Empfang von einer SUBACK-Nachricht aufgerufen.
     */
    @Override
    public void SuBackReceivedCallback(MsgSubAck msg) {
        _appListener.SuBackReceivedCallback(msg.SubscribeFailure, msg.MaxQoS, msg.Topic);
    }

    /**
     * \brief Methode wird beim Empfang von einer UNSUBACK-Nachricht aufgerufen.
     *
     */
    @Override
    public void UnSuBackReceivedCallback(MsgUnSubAck msg) {
        _appListener.UnSuBackReceivedCallback(msg.Topic);
    }

    /**
     * \brief Methode wird bei einem Fehler im Receiver-Thread aufgerufen.
     */
    @Override
    public void ErrorOccurredCallback(MqttException me) {
        disconnect(me.Reason);
    }
    // #endregion

    // #region Connect

    public static String byteArrayToHex(byte[] a) {
        StringBuilder sb = new StringBuilder(a.length * 2);
        for (byte b : a)
            sb.append(String.format("%02x ", b));
        return sb.toString();
    }

    /**
     * \brief Baut eine Verbindung zum Broker auf.
     *
     * @param broker       Hostname für den Broker
     * @param port         Port für die Verbindung
     * @param id           Eindeutige Client-ID
     * @param user         Username
     * @param pass         Passwort
     * @param willTopic    Topic für 'last will'
     * @param willQos      QoS für 'lat will'
     * @param willRetain   Retain-Flag für 'last will'
     * @param willMessage  'last will'-Nachricht
     * @param cleanSession 'Clean Session'-Flag
     * @param keepAlive    Sekunden für KeepAlive
     * @param IoTimeout    Timeout für den Datentransfer in Sekunden
     */
    public void connect(final String broker, final int port, final String id, final boolean cleanSession,
            final String user, final String pass, final String willTopic, final byte willQos, final boolean willRetain,
            final String willMessage, final int keepAlive, final int IoTimeout) {

        ConnectionStateChangedEvent(MqttConnectionState.Connecting, 0, "");

        final UrsMqttClient mqttClient = this; // wird für die Lambda-Funktion benötigt
        stopReceiver(); // sicherheitshalber einen bestehenden Thread beenden

        mqttChannel = new MqttTcpChannel(broker, port, IoTimeout, IoTimeout, keepAlive);

        Runner.start(new Runnable() {
            public void run() {
                MsgConnect mc = null;

                try {
                    mqttChannel.connect();
                    mrt = new MqttMessageHandler(mqttChannel, mqttClient, keepAlive);
                    mrt.start();
                    mc = new MsgConnect(id, cleanSession, user, pass, willTopic, willQos, willRetain, willMessage,
                            keepAlive);
                    mrt.xmit(mc);
                } catch (MqttException e) {
                    ConnectionStateChangedEvent(MqttConnectionState.ConnectionAbortet, e.Reason.errorCode,
                            e.Reason.errorText);
                    return;
                } // try
            } // run
        }); // Runnable
    }
    // #endregion

    private void stopReceiver() {
        if (mrt == null) // kein aktiver Thread vorhanden
            return;
        if (mrt.isAlive()) {
            if (!mrt.isAborting) {
                mrt.stopRequest = true;
                Thread.yield();
            }
        }
        mrt = null;
    }

    // #region Disconnect
    /**
     * \brief Trennt die Verbindung um Broker.
     */
    public void disconnect() {
        ConnectionStateChangedEvent(MqttConnectionState.Disconnecting, 0, "");
        Runner.start(new Runnable() {
            public void run() {
                try {
                    mrt.xmit(new MsgDisconnect());
                } catch (MqttException e) {
                    stopReceiver();
                    mqttChannel.disconnect();
                    ConnectionStateChangedEvent(MqttConnectionState.ConnectionAbortet, e.Reason.errorCode,
                            e.Reason.errorText);
                    return;
                }

                stopReceiver();
                mqttChannel.disconnect();
                ConnectionStateChangedEvent(MqttConnectionState.Disconnected, 0, "");
            } // run
        }); // Runnable
    }

    private void disconnect(final MqttErrorCode ec) {
        Runner.start(new Runnable() {
            public void run() {
                ConnectionStateChangedEvent(MqttConnectionState.Disconnecting, ec.errorCode, ec.errorText);
                mqttChannel.disconnect();
                ConnectionStateChangedEvent(MqttConnectionState.ConnectionAbortet, ec.errorCode, ec.errorText);
            } // run
        }); // Runnable
    }
    // #endregion

    // #region Subscribe / Unsubscribe
    /**
     * \brief Versendet eine SUBSCRIBE-Nachricht. \note Wenn die Nachricht nicht
     * versandt werden konnte, wird die Verbindung getrennt.
     *
     * @param topic Topic, dass abboniert werden soll.
     * @param qos   QoS für dieses Topic.
     */
    void subscribe(final String topic, final byte qos) {
        Runner.start(new Runnable() {
            public void run() {
                MsgSubscribe ms;
                ms = new MsgSubscribe(topic, qos);
                try {
                    mrt.xmit(ms);
                } catch (MqttException me) {
                    disconnect(me.Reason);
                } // try
            } // run
        }); // Runnable
    }

    /**
     * \brief Versendet eine UNSUBSCRIBE-Nachricht. \note Wenn die Nachricht nicht
     * versandt werden konnte, wird die Verbindung getrennt.
     *
     * @param topic Topic, dass nicht mehr abboniert sein soll.
     */
    void unsubscribe(final String topic) {
        Runner.start(new Runnable() {
            public void run() {
                MsgUnsubscribe ms;
                ms = new MsgUnsubscribe(topic);
                try {
                    mrt.xmit(ms);
                } catch (MqttException me) {
                    disconnect(me.Reason);
                } // try
            } // run
        }); // Runnable
    }
    // #endregion

    // #region Publish
    /**
     * \brief Versendet eine PUBLISH-Nachricht. Wenn die Nachricht nicht versandt
     * werden konnte, wird die Verbindung getrennt.
     *
     * @param topic    Topic für diese Nachricht
     * @param message  Nutzdaten.
     * @param retained Retained-Flag.
     */
    public void publish(String topic, String message, boolean retained, byte qos) {
        publish(topic, message.getBytes(UrsMqttClient.Charset), retained, qos);
    }

    /**
     * \brief Versendet eine PUBLISH-Nachricht. Wenn die Nachricht nicht versandt
     * werden konnte, wird die Verbindung getrennt.
     *
     * @param topic    Topic für diese Nachricht
     * @param message  Nutzdaten.
     * @param retained Retained-Flag.
     * @param qos      QoS.
     */
    public void publish(final String topic, final byte[] payload, final boolean retained, final byte qos) {
        Runner.start(new Runnable() {
            public void run() {
                MsgPublish msg;
                msg = new MsgPublish(topic, payload, retained, qos);

                try {
                    mrt.xmit(msg);
                } catch (MqttException me) {
                    disconnect(me.Reason);
                } catch (Exception e) {
                    disconnect(MqttErrorCode.XmitError);
                } // try
            } // run
        }); // Runnable
    }
    // #endregion
}