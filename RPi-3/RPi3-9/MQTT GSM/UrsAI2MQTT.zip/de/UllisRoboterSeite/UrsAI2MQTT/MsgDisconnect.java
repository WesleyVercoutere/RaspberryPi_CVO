package de.UllisRoboterSeite.UrsAI2MQTT;;

/**
 * \brief Repräsentiert eine MQTT-Nachricht vom Typ DISCONNECT
 */
public class MsgDisconnect extends MsgMqtt {
    /**
     * \brief Initializiert eine neue Instanz der MsgDisconnect-Klasse.
     */
    MsgDisconnect() {
        super(MsgType.MQTTDISCONNECT);
    }
}