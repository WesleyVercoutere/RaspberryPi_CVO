package de.UllisRoboterSeite.UrsAI2MQTT;;

/**
 * \brief Datenaustausch zwischen Receiver-Thread und Client (Front-End).
 */
public interface IMqttListener {
    /**
     * \brief Wird aufgerufen, wenn eine Nachricht vom Typ PUBLISH empfangen wurde.
     *
     * @param msg Die empfangene Nachricht.
     */
    public void PublishedReceivedCallback(MsgPublish msg);

    /**
     * \brief Wird aufgerufen, wenn eine Nachricht vom Typ SUBACK empfangen wurde.
     *
     * @param msg Die empfangene Nachricht.
     */
    public void SuBackReceivedCallback(MsgSubAck msg);

    /**
     * \brief Wird aufgerufen, wenn eine Nachricht vom Typ UNSUBACK empfangen wurde.
     *
     * @param msg Die empfangene Nachricht.
     */
    public void UnSuBackReceivedCallback(MsgUnSubAck msg);

    /**
     * \brief Wird aufgerufen, wenn eine Nachricht vom Typ CONNACK empfangen wurde.
     *
     * @param msg Die empfangene Nachricht.
     */
    public void ConnectedAckCallback(MsgConnAck msg);

    /**
     * \brief Wird aufgerufen, wenn im Receiver-Thread ein Fehler aufgetaucht ist.
     * @param me Die Exception enthält die Fehlerursache.
     */
    public void ErrorOccurredCallback(MqttException me);
}