package de.UllisRoboterSeite.UrsAI2MQTT;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.locks.ReentrantLock;

/**
 * \brief Thread, der Nachrichten des Brokers einliest und analysiert.
 */
public class MqttMessageHandler extends Thread {
    IMqttChannel mqttChannel;
    long lastInActivity = 0; // Zeitpunkt des letzten Datenempfangs
    long lastOutActivity = 0; // Zeitpunkt des letzten Datenversands
    IMqttListener mqttListener;
    long keepAliveMilliseconds;
    LinkedList<MsgMqtt> OutboundQueue = new LinkedList<MsgMqtt>();
    LinkedList<MsgPublish> InboundQueue = new LinkedList<MsgPublish>();
    private final ReentrantLock QueueLock = new ReentrantLock();

    public boolean stopRequest = false; /// < \brief true, wenn der Thread beendet werden soll.
    public boolean isAborting = false; /// < \brief true, wenn der Thread abgebrochen wurde.

    /**
     * \brief Initialisiert eine neue Instanz der Klasse \ref MqttReceiverThread.
     * Bei jedem Verbindungsaufbau wird eine neue Instanz dieser Klasse erzeugt und
     * beim Verbindungsabbau wieder zerstört. Die erste Aktion der übergeordneten
     * Schicht ist das Versenden eine CONNECT-Nachricht.
     *
     * @param channel          Instanz der Klasse \ref MqttNetworkClient, die zur
     *                         Ein- und Ausagbe benutzt werden soll.
     * @param listener         Instanz des Interface \ref IMqttListener, das
     *                         Nachrichten verarbeiten soll.
     * @param keepAliveSeconds Anzahl Sekunden für Timeout
     */
    public MqttMessageHandler(IMqttChannel channel, IMqttListener listener, int keepAliveSeconds) {
        mqttChannel = channel;
        mqttListener = listener;
        keepAliveMilliseconds = keepAliveSeconds * 1000;
    }

    @Override
    public void run() {
        lastInActivity = System.currentTimeMillis();
        OutboundQueue.clear();

        try {
            while (!stopRequest) {
                handleIncommingMessage();
                handlePendingActions();
                Thread.yield();
            }
        } catch (MqttException e) {
            isAborting = true; // Dies ist die letzte Aktion
            mqttListener.ErrorOccurredCallback(e);
        }
        isAborting = true;
    }

    /**
     * \brief Prüft auf ausstehende Aktionen und behandelt diese.
     *
     * @throws MqttException Austehende Aktionen wurden nicht oder nicht zeitgerecht
     *                       behandelt.
     */
    private void handlePendingActions() throws MqttException {
        long t = System.currentTimeMillis();
        long timetouted = t - keepAliveMilliseconds;

        try {
            QueueLock.lock();
            Iterator<MsgMqtt> iterator = OutboundQueue.iterator();
            while (iterator.hasNext()) {
                MsgMqtt msg = iterator.next();
                if (msg.messageSentAt < timetouted) {
                    MsgMqtt fmsg = msg.timeoutAction();
                    if (msg != null)
                        xmit(fmsg, false);
                }
            }
        } finally {
            QueueLock.unlock();
        }

        if ((t - lastInActivity > keepAliveMilliseconds)) {
            MsgPingRequest mp = new MsgPingRequest();
            xmit(mp);
        }

        if (lastOutActivity != 0) {
            if ((t - lastOutActivity > keepAliveMilliseconds - 1000)) { // 1000 ms Zeit für den Server zu antworten
                MsgPingRequest mp = new MsgPingRequest();
                xmit(mp);
            }
        }
    }

    /**
     * \brief Liest eingehende Nachrichten ein und reagiert darauf.
     *
     * @throws MqttException Die Nachricht konnte nicht korrekt eingelesen oder
     *                       entschlüsselt werden.
     */
    private void handleIncommingMessage() throws MqttException {
        if (!mqttChannel.available()) // Es steht keine Daten an
            return;

        MsgMqtt msg = MsgMqtt.fromBuffer(MqttPacketBuffer.fromStream(mqttChannel));
        if (msg == null) {
            return;
        }

        System.out.println("Message  got: " + msg.toString()); // TODO: entfernen 'Message got'

        lastInActivity = System.currentTimeMillis();
        Iterator<MsgMqtt> iterator;

        switch (msg.getType()) {
        case MQTTPUBLISH:
            // #region MQTTPUBLISH
            MsgPublish mpu = (MsgPublish) msg;
            switch (mpu.getQoS()) {
            case 0:
                mqttListener.PublishedReceivedCallback(mpu);
                break;
            case 1:
                mqttListener.PublishedReceivedCallback(mpu);
                xmit(new MsgPubAck(mpu.packetIdentifier));
                break;
            case 2:
                // InboundQueue prüfen
                boolean found = false;
                try {
                    QueueLock.lock();
                    Iterator<MsgPublish> it = InboundQueue.iterator();
                    while (it.hasNext()) {
                        MsgPublish m = it.next();
                        if (m.packetIdentifier == mpu.packetIdentifier)
                            found = true;
                        break; // while
                    }
                } finally {
                    QueueLock.unlock();
                }
                if (!found)
                    mqttListener.PublishedReceivedCallback(mpu);
                xmit(new MsgPubRec(mpu.packetIdentifier));
                break;
            } // switch (mpu.getQoS())
            break;
        // #endregion
        case MQTTPUBACK:
            // #region MQTTPUBACK
            // Ausstehende Nachrichten vom Typ MsgPublish mit gleicher Paket-ID löschen.
            try {
                QueueLock.lock();
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTPUBLISH) {
                        if (m.packetIdentifier == msg.packetIdentifier)
                            iterator.remove();
                    }
                }
            } finally {
                QueueLock.unlock();
            }
            break;
        // #endregion
        case MQTTPUBREC:
            // #region MQTTPUBREC
            try {
                QueueLock.lock();
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTPUBLISH) {
                        if (m.packetIdentifier == msg.packetIdentifier)
                            iterator.remove();
                    }
                }
            } finally {
                QueueLock.unlock();
            }
            xmit(new MsgPubRel(msg.packetIdentifier));
            break;
        // #endregion
        case MQTTPUBREL:
            // #region MQTTPUBREL
            try {
                QueueLock.lock();
                Iterator<MsgPublish> it = InboundQueue.iterator();
                // aus der Inbound-Queue löschen
                while (it.hasNext()) {
                    MsgPublish m = it.next();
                    if (m.packetIdentifier == msg.packetIdentifier) {
                        it.remove();
                        break; // while
                    }
                }
                // PUBREC aus der Outbound-Queue löschen
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTPUBREC) {
                        if (m.packetIdentifier == msg.packetIdentifier)
                            iterator.remove();
                    }
                }
            } finally {
                QueueLock.unlock();
            }
            xmit(new MsgPubComp(msg.packetIdentifier));
            break;
        // #endregion
        case MQTTPUBCOMP:
            // #region MQTTPUBCOMP
            try {
                QueueLock.lock();
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTPUBREL) {
                        if (m.packetIdentifier == msg.packetIdentifier)
                            iterator.remove();
                    }
                }
            } finally {
                QueueLock.unlock();
            }
            break;
        // #endregion
        case MQTTPINGREQ:
            // #region MQTTPINGREQ
            MsgPingResponse mp = new MsgPingResponse();
            xmit(mp);
            break;
        // #endregion
        case MQTTPINGRESP:
            // #region MQTTPINGRESP
            // Alle ausstehende Nachrichten vom Typ MsgPingRequest löschen.
            try {
                QueueLock.lock();
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTPINGREQ)
                        iterator.remove();
                }
            } finally {
                QueueLock.unlock();
            }

            break;
        // #endregion
        case MQTTCONNACK:
            // #region MQTTCONNACK
            // Alle ausstehende Nachrichten vom Typ MsgConnect löschen.
            mqttListener.ConnectedAckCallback(((MsgConnAck) msg));
            try {
                QueueLock.lock();
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTCONNECT)
                        iterator.remove();
                }
            } finally {
                QueueLock.unlock();
            }
            break;
        // #endregion
        case MQTTSUBACK:
            // #region MQTTSUBACK
            // Ausstehende Nachrichten vom Typ MsgSubscribe mit gleicher Paket-ID löschen.
            try {
                QueueLock.lock();
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTSUBSCRIBE) {
                        if (m.packetIdentifier == msg.packetIdentifier) {
                            ((MsgSubAck) msg).Topic = ((MsgSubscribe) m).Topic;
                            iterator.remove();

                        }
                    }
                }
            } finally {
                QueueLock.unlock();
            }
            mqttListener.SuBackReceivedCallback((MsgSubAck) msg);
            break;
        case MQTTUNSUBACK:
            // #region MQTTUNSUBACK
            // Ausstehende Nachrichten vom Typ MsgUnSubscribe mit gleicher Paket-ID löschen.
            try {
                QueueLock.lock();
                iterator = OutboundQueue.iterator();
                while (iterator.hasNext()) {
                    MsgMqtt m = iterator.next();
                    if (m.getType() == MsgType.MQTTUNSUBSCRIBE) {
                        if (m.packetIdentifier == msg.packetIdentifier) {
                            ((MsgUnSubAck) msg).Topic = ((MsgUnsubscribe) m).Topic;
                            iterator.remove();
                        }
                    }
                }
            } finally {
                QueueLock.unlock();
            }
            mqttListener.UnSuBackReceivedCallback((MsgUnSubAck) msg);
            break;
        default:
            break;
        }
        // #endregion
    }

    /**
     * \brief Fügt die Nachricht der Liste der Nachrichten hinzu, die auf eine
     * Antwort des Brokers warten.
     *
     * @param msg Die anzufügende Nachricht.
     */
    void addPendingMessage(MsgMqtt msg) {
        if (!msg.mustBeConfirmed())
            return;

        QueueLock.lock();
        OutboundQueue.add(msg);
        if (msg.getType() == MsgType.MQTTPUBLISH) {
            MsgPublish mp = (MsgPublish) msg;
            if (mp.getQoS() == 2) {
                boolean found = false;
                try {
                    QueueLock.lock();
                    Iterator<MsgPublish> it = InboundQueue.iterator();
                    while (it.hasNext()) {
                        MsgPublish m = it.next();
                        if (m.packetIdentifier == mp.packetIdentifier)
                            found = true;
                        break; // while
                    }
                } finally {
                    QueueLock.unlock();
                }
                if (!found)
                    InboundQueue.add(mp);
            }
        }
        QueueLock.unlock();
    }

    /**
     * \brief Versendet die angegebene MQTT-Nachricht.
     *
     * @param msg Die MQTT-Nachricht, die versendet werden soll.
     * @throws MqttException Die Nachricht konnte noicht versandt werden.
     */
    public void xmit(MsgMqtt msg) throws MqttException {
        xmit(msg, true);
    }

    // intener Aufruf ohne Nachrichtenspeicher bei Wiederholung
    void xmit(MsgMqtt msg, boolean addToQueue) throws MqttException {
        byte[] buf = msg.getRawBuffer();

        System.out.println("Message sent: " + msg.toString() + " Retry: " + !addToQueue); // TODO: entfernen 'Message
                                                                                          // sent'

        try {
            mqttChannel.xmit(buf);
            long t = System.currentTimeMillis();
            msg.messageSentAt = t;
            lastOutActivity = t;
            if (addToQueue)
                addPendingMessage(msg);
        } catch (Exception e) {
            throw new MqttException(MqttErrorCode.XmitError, e);
        }
    }
}