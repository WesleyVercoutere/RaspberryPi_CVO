package de.UllisRoboterSeite.UrsAI2MQTT;;

/**
 * \brief Datenaustausch zwischen Client und AI2 Extension.
 */
public interface IExtensionListener {
    /**
     * \brief Wird aufgerufen, wenn eine Nachricht vom Typ PUBLISH empfangen wurde.
     *
     * @param topic  Das Topic.
     * @param msg    Die Nachrichtendaten als String.
     * @param retain Das Retain-Flag.
     * @param dup    Das Dup-Flag.
     */
  //  public void PublishedReceivedCallback(String topic, byte[] payload, String msg, boolean retain, boolean dup);
  public void PublishedReceivedCallback(MsgPublish mp);
    /**
     * \brief Wird aufgerufen, wenn eine Nachricht vom Typ SUBACK empfangen wurde.
     *
     * @param Failure Gibt an, ob die zugehörige SUBSCRIBE-Nachricht verarbeitet
     *                werden konnte.
     * @param maxQoS  Die maximale QoS-Stufe, die dem Abonnement gewährt wurde, das
     *                vom der zugehörigen SUBSCRIBE-Nachricht angefordert wurde.
     * @param topic   Topic der zugehörigen SUBSCRIBE-Nachricht.
     */
    public void SuBackReceivedCallback(boolean Failure, int maxQos, String topic);

    /**
     * \brief Wird aufgerufen, wenn eine Nachricht vom Typ UNSUBACK empfangen wurde.
     *
     * @param topic   Topic der zugehörigen SUBSCRIBE-Nachricht.
     */
    public void UnSuBackReceivedCallback(String topic);

    /**
     * \brief Wird aufgerufen, wenn sich der Verbindungszustand ändert.
     *
     * @param NewState  Der neue Zustand.
     * @param errorCode Fehler-Code, wenn die Verbindung durch einen Fehler nicht
     *                  hergestellt werden konnte oder unterbrochen wurde. Ansonten
     *                  0.
     * @param errorText Zugehöriger Fehler-Text.

     */
    public void ConnectionStateChangeCallback(MqttConnectionState newState, int errorCode, String errorText);
}